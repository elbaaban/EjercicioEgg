
package com.tienda.persistencia;

public class FabricanteDao {
    
}

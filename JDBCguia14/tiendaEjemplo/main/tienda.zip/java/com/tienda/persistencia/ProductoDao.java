
package com.tienda.persistencia;

public class ProductoDao {
    
}

package entidades;

public class PersonalServicio extends Empleado{
    protected String seccion;

    public PersonalServicio() {
    }
    public PersonalServicio(String nombre, String apellido, int dni, String estadoCivil, int anioIngreso, int numeroDespacho, String seccion) {
        super(nombre, apellido, dni, estadoCivil, anioIngreso, numeroDespacho);
        this.seccion = seccion;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }
}

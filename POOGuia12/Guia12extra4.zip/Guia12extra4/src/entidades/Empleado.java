package entidades;

public class Empleado extends Persona{

    protected int anioIngreso;
    protected int numeroDespacho;

    public Empleado() {
    }
    public Empleado(String nombre, String apellido, int dni, String estadoCivil, int anioIngreso, int numeroDespacho) {
        super(nombre, apellido, dni, estadoCivil);
        this.anioIngreso = anioIngreso;
        this.numeroDespacho = numeroDespacho;
    }

    public int getAnioIngreso() {
        return anioIngreso;
    }

    public void setAnioIngreso(int anioIngreso) {
        this.anioIngreso = anioIngreso;
    }

    public int getNumeroDespacho() {
        return numeroDespacho;
    }

    public void setNumeroDespacho(int numeroDespacho) {
        this.numeroDespacho = numeroDespacho;
    }
}

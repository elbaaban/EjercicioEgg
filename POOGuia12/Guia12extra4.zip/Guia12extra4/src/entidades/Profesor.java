package entidades;

public class Profesor extends Empleado{
    protected String materia;

    public Profesor() {
    }
    public Profesor(String nombre, String apellido, int dni, String estadoCivil, int anioIngreso, int numeroDespacho, String materia) {
        super(nombre, apellido, dni, estadoCivil, anioIngreso, numeroDespacho);
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }
}

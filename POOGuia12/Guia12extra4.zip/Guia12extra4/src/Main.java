import Service.PersonaService;

public class Main {
    public static void main(String[] args) {
        PersonaService personaService = new PersonaService();
        personaService.crearIndividuo();
    }
}
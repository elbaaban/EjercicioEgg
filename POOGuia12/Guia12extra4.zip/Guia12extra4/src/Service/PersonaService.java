package Service;

import entidades.*;

import java.util.ArrayList;
import java.util.Scanner;

public class PersonaService {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearIndividuo() {
        //crear un menu donde me de como opciones crear un estudiante, un profesor o un personal de servicio
        //crear un metodo para cada uno de ellos
        ArrayList<Persona> personas = new ArrayList<>();
        boolean salir = false;
        while (!salir) {
            System.out.println("Ingrese la opcion deseada: ");
            System.out.println("1. Crear un estudiante");
            System.out.println("2. Crear un profesor");
            System.out.println("3. Crear un personal de servicio");
            System.out.println("4. Modificar un individuo");
            System.out.println("5. Imprimir lista de personas");
            System.out.println("6. Salir");
            int opcion = leer.nextInt();
            switch (opcion) {
                case 1 -> personas.add(crearEstudiante());
                case 2 -> personas.add(crearProfesor());
                case 3 -> personas.add(crearPersonalServicio());
                case 4 -> buscarPersona(personas);
                case 5 -> imprimirInformacion(personas);
                case 6 -> salir = true;
                default -> System.out.println("Opcion incorrecta");
            }
        }
    }
    private void buscarPersona(ArrayList<Persona> personas) {
        System.out.println("Ingrese el dni de la persona que desea buscar");
        int dni = leer.nextInt();
        for (Persona persona : personas) {
            if (persona.getDni() == dni) {
                modificarIndividuo(persona);
            }
        }
    }
    //crear un menu donde le ingrese por parametro un arraylist de personas y me de como opciones
    //los metodos para modificar un estudiante, un profesor o un personal de servicio
    private void modificarIndividuo(Persona persona) {
        boolean salir = false;
        while (!salir) {
            System.out.println("Ingrese la opcion deseada: ");
            System.out.println("1. Cambiar estado civil");
            System.out.println("2. Reasignacion de despacho a un empleado");
            System.out.println("3. Matricular a un estudiantes en un curso");
            System.out.println("4. Cambiar de departamento a un profesor");
            System.out.println("5. Cambiar de seccion a un personal de servicio");
            System.out.println("6. Cambiar de curso a un estudiante");
            System.out.println("7. Salir");
            int opcion = leer.nextInt();
            switch (opcion) {
                case 1:
                    cambiarEstadoCivil(persona);
                    break;
                case 2:
                    Empleado empleado = (Empleado) persona;
                    reasignarDespacho(empleado);
                    break;
                case 3:
                    Estudiante estudiante = (Estudiante) persona;
                    matricularEstudiante(estudiante);
                    break;
                case 4:
                    Profesor profesor = (Profesor) persona;
                    cambiarDepartamento(profesor);
                    break;
                case 5:
                    PersonalServicio personalServicio = (PersonalServicio) persona;
                    trasladarSeccion(personalServicio);
                    break;
                case 6:
                    break;
                case 7:
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion incorrecta");
            }
        }
    }
    private Estudiante crearEstudiante() {
        //crear un estudiante
        System.out.println("Ingrese el nombre del estudiante: ");
        String nombre = leer.next();
        System.out.println("Ingrese el apellido del estudiante: ");
        String apellido = leer.next();
        System.out.println("Ingrese el DNI del estudiante: ");
        int dni = leer.nextInt();
        System.out.println("Ingrese el estado civil del estudiante: ");
        String estadoCivil = leer.next();
        System.out.println("Ingrese el curso del estudiante: ");
        String curso = leer.next();
        return new Estudiante(nombre, apellido, dni, estadoCivil, curso);
    }
    private Profesor crearProfesor() {
        //crear un profesor
        System.out.println("Ingrese el nombre del profesor: ");
        String nombre = leer.next();
        System.out.println("Ingrese el apellido del profesor: ");
        String apellido = leer.next();
        System.out.println("Ingrese el DNI del profesor: ");
        int dni = leer.nextInt();
        System.out.println("Ingrese el estado civil del profesor: ");
        String estadoCivil = leer.next();
        System.out.println("Ingrese el año de ingreso del profesor: ");
        int anioIngreso = leer.nextInt();
        System.out.println("Ingrese el numero de despacho del profesor: ");
        int numeroDespacho = leer.nextInt();
        System.out.println("Ingrese la materia del profesor: ");
        String materia = leer.next();
        return new Profesor(nombre, apellido, dni, estadoCivil, anioIngreso, numeroDespacho, materia);
    }
    private PersonalServicio crearPersonalServicio() {
        //crear un personal de servicio
        System.out.println("Ingrese el nombre del personal de servicio: ");
        String nombre = leer.next();
        System.out.println("Ingrese el apellido del personal de servicio: ");
        String apellido = leer.next();
        System.out.println("Ingrese el DNI del personal de servicio: ");
        int dni = leer.nextInt();
        System.out.println("Ingrese el estado civil del personal de servicio: ");
        String estadoCivil = leer.next();
        System.out.println("Ingrese el año de ingreso del personal de servicio: ");
        int anioIngreso = leer.nextInt();
        System.out.println("Ingrese el numero de despacho del personal de servicio: ");
        int numeroDespacho = leer.nextInt();
        System.out.println("Ingrese la seccion del personal de servicio: ");
        String seccion = leer.next();
        return new PersonalServicio(nombre, apellido, dni, estadoCivil, anioIngreso, numeroDespacho, seccion);
    }
    public void cambiarEstadoCivil(Persona persona) {
        System.out.println("Ingrese el nuevo estado civil de la persona: ");
        String estadoCivil = leer.next();
        persona.setEstadoCivil(estadoCivil);
    }
    //• Reasignación de despacho a un empleado.
    public void reasignarDespacho(Empleado empleado) {
        System.out.println("Ingrese el nuevo numero de despacho del empleado: ");
        int numeroDespacho = leer.nextInt();
        empleado.setNumeroDespacho(numeroDespacho);
    }
    //• Matriculación de un estudiante en un nuevo curso.
    public void matricularEstudiante(Estudiante estudiante) {
        System.out.println("Ingrese el nuevo curso del estudiante: ");
        String curso = leer.next();
        estudiante.setCurso(curso);
    }
    //• Cambio de departamento de un profesor.
    public void cambiarDepartamento(Profesor profesor) {
        System.out.println("Ingrese el nuevo departamento del profesor: ");
        String departamento = leer.next();
        profesor.setMateria(departamento);
    }
    //• Traslado de sección de un empleado del personal de servicio.
    public void trasladarSeccion(PersonalServicio personalServicio) {
        System.out.println("Ingrese la nueva seccion del personal de servicio: ");
        String seccion = leer.next();
        personalServicio.setSeccion(seccion);
    }
    //• Imprimir toda la información de cada tipo de individuo. Incluya un programa de prueba
    //que instancie objetos de los distintos tipos y pruebe los métodos desarrollados.
    public void imprimirInformacion(ArrayList<Persona> arrayPersonas) {
        for (Persona arrayPersona : arrayPersonas) {
            if (!(arrayPersona instanceof Estudiante estudiante)) {
                if (arrayPersona instanceof Profesor) {
                    Profesor profesor = (Profesor) arrayPersona;
                    System.out.println("Profesor");
                    System.out.println("Nombre: " + profesor.getNombre());
                    System.out.println("Apellido: " + profesor.getApellido());
                    System.out.println("DNI: " + profesor.getDni());
                    System.out.println("Estado civil: " + profesor.getEstadoCivil());
                    System.out.println("Año de ingreso: " + profesor.getAnioIngreso());
                    System.out.println("Numero de despacho: " + profesor.getNumeroDespacho());
                    System.out.println("Materia: " + profesor.getMateria());
                } else {
                    PersonalServicio personalServicio = (PersonalServicio) arrayPersona;
                    System.out.println("Personal de servicio");
                    System.out.println("Nombre: " + personalServicio.getNombre());
                    System.out.println("Apellido: " + personalServicio.getApellido());
                    System.out.println("DNI: " + personalServicio.getDni());
                    System.out.println("Estado civil: " + personalServicio.getEstadoCivil());
                    System.out.println("Año de ingreso: " + personalServicio.getAnioIngreso());
                    System.out.println("Numero de despacho: " + personalServicio.getNumeroDespacho());
                    System.out.println("Seccion: " + personalServicio.getSeccion());
                }
            } else {
                System.out.println("Estudiante");
                System.out.println("Nombre: " + estudiante.getNombre());
                System.out.println("Apellido: " + estudiante.getApellido());
                System.out.println("DNI: " + estudiante.getDni());
                System.out.println("Estado civil: " + estudiante.getEstadoCivil());
                System.out.println("Curso: " + estudiante.getCurso());
            }

        }
    }


}

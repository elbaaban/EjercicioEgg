/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 * 
 * 
 * @author Diego
 */
public class Bota extends Dispositivo{

    public Bota(float consumoEnergia) {
        super(consumoEnergia);
    }

    public Bota() {
    }
    
    
    
}

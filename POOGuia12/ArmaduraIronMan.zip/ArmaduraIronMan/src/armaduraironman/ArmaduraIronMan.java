/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package armaduraironman;

import Entidades.ArmaduraIron;

/**
 *
 * @author Diego
 */
public class ArmaduraIronMan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArmaduraIron ironman=new ArmaduraIron();
        ironman.menu();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia11.extra4;

import entidades.Alumno;
import entidades.Voto;
import java.util.ArrayList;
import servicios.Simulador;

/**
 *
 * @author Carlos Ezequiel Diaz
 */
public class Guia11Extra4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Simulador s = new Simulador ();
        
        ArrayList <Alumno> ListaAlumnos = s.ListaAlumnos(s.ListaNombres(), s.dnis());
        
        s.imprimir(ListaAlumnos);
        
        ArrayList<Voto> votos = s.votacion(ListaAlumnos);
        
        s.MostrarVotos(ListaAlumnos, votos);
        
        System.out.println("****************************************");
        
        //s.imprimir(ListaAlumnos);
        s.recuentoVotos(ListaAlumnos);
        s.facilitadores(ListaAlumnos);
        s.recuentoVotos(ListaAlumnos);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.HashSet;

/**
 *Una vez hecho esto debemos generar una clase Voto, esta clase tendrá como atributos,
un objeto Alumno que será el alumno que vota y una lista de los alumnos a los que votó.
 * @author Carlos Ezequiel Diaz
 */
public class Voto {
 
    private Alumno alum;
    private HashSet <Alumno> AlumnosVotados;

    public Voto() {
        
        AlumnosVotados = new HashSet <Alumno>();
    }

    public Voto(Alumno alum, HashSet<Alumno> AlumnosVotados) {
        this.alum = alum;
        this.AlumnosVotados = AlumnosVotados;
    }

    public Voto(Alumno alum) {
        this.alum = alum;
        AlumnosVotados = new HashSet <Alumno>();
    }
    

    public Alumno getAlum() {
        return alum;
    }

    public void setAlum(Alumno alum) {
        this.alum = alum;
    }

    public HashSet<Alumno> getAlumnosVotados() {
        return AlumnosVotados;
    }

    public void setAlumnosVotados(HashSet<Alumno> AlumnosVotados) {
        this.AlumnosVotados = AlumnosVotados;
    }

    
    
    
    
    
    @Override
    public String toString() {
        return "Voto{" + "alum=" + alum + ", AlumnosVotados=" + AlumnosVotados + '}';
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import entidades.Alumno;
import java.util.Comparator;

/**
 *
 * @author Carlos Ezequiel Diaz
 */
public class comparadores implements Comparator <Alumno>{

    @Override
    public int compare(Alumno t, Alumno t1) {
        
        Integer v = t.getVotos();
        Integer v1 = t1.getVotos();
        
        return v1.compareTo(v);
                
                
                }
    
    
    
}

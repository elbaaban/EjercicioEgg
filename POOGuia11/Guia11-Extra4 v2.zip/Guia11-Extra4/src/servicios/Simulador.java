/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import entidades.Alumno;
import entidades.Voto;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Carlos Ezequiel Diaz
 */
public class Simulador {
    
    Scanner leer = new Scanner (System.in);
    
    /*La clase Simulador debe tener un método que genere un listado de nombres completos manera
aleatoria y lo retorne. Las combinaciones de nombre y apellido deben ser generadas de
manera aleatoria. Nota: usar listas de tipo String para generar los nombres y los apellidos.*/
    
    public String[] ListaNombres (){
        
        String [] nombres = {"Carlos","Omar","Franklin","Nicolas","Diego","Rodrigo","José","Abdallah"};
        String [] apellidos = {"Casanotam","Diaz","Marquez","Barni","Aranda","Zoppi","Pitton","Monroy"};
        
        String [] listadoNombres = new String[64];
        int cont=0;
        
        Random random = new Random();
        
        for (int i = 0; i < 64; i++) {
            String nombre = nombres[(random.nextInt(8))];
            String apellido = apellidos[(random.nextInt(8))];

            listadoNombres[i] = nombre + " " + apellido;

             
        }
        
           return listadoNombres;
    }
        
    
    /*Ahora hacer un generador de combinaciones de DNI posibles, deben estar dentro de un
rango real de números de documentos. Este método debe retornar la lista de dnis.*/
    
    public HashSet<Integer> dnis (){
        
        HashSet <Integer> dnis = new HashSet();
        
        while (dnis.size()<64){
            
            dnis.add ((int) (Math.random()*50000000+7000000));
        }
            
        
        return dnis;
    }
    
    
    /*Ahora tendremos un método que, usando las dos listas generadas, cree una cantidad de
objetos Alumno, elegidos por el usuario, y le asigne los nombres y los dnis de las dos
listas a cada objeto Alumno. No puede haber dos alumnos con el mismo dni, pero si con el
mismo nombre.*/
    
    public ArrayList<Alumno> ListaAlumnos(String[] Nombres, HashSet<Integer> dnis) {

        System.out.print("Cuantos alumnos desea generar (max 64): ");
        int cant = leer.nextInt();
        
        if (cant>64){
            cant=64;
            System.out.println("Se consideran 64 alumnos");
            
        }

        ArrayList<Alumno> ListaAlumnos = new ArrayList();

        int cont = 0;

        for (Integer dni : dnis) {

            if (cont >= cant) {

                break;
            }

            ListaAlumnos.add(new Alumno(Nombres[cont], dni, 0));
            cont++;

        }
        
        return ListaAlumnos;
        
    }
    
    /*Se debe imprimir por pantalla el listado de alumnos.*/
    
    public void imprimir (ArrayList<Alumno> ListaAlumnos){
        
        System.out.println(ListaAlumnos);
        
    }
    
    /*Crearemos un método votación en la clase Simulador que, recibe el listado de alumnos y
para cada alumno genera tres votos de manera aleatoria. En este método debemos
guardar a el alumno que vota, a los alumnos a los que votó y sumarle uno a la cantidad de
votos a cada alumno que reciba un voto, que es un atributo de la clase Alumno.
Tener en cuenta que un alumno no puede votarse a sí mismo o votar más de una vez al
mismo alumno. Utilizar un hashset para resolver esto.*/
    
    public ArrayList<Voto> votacion(ArrayList<Alumno> ListaAlumnos) {
        
        ArrayList<Voto> votos = new ArrayList();
        
        for (int i = 0; i < ListaAlumnos.size(); i++) {
            
            Voto v = new Voto((ListaAlumnos.get(i)));
                        
            HashSet<Alumno> alumnosVotados = new HashSet();
            
            while (alumnosVotados.size() < 3) {

                Alumno voto1 = ListaAlumnos.get((int) (Math.random() * (ListaAlumnos.size())));

                if (voto1.getDni() != ListaAlumnos.get(i).getDni()) {
                  

                        alumnosVotados.add(voto1);
                        System.out.println("El alumno "+ListaAlumnos.get(i).getNombre()+" voto a "+voto1);

                        

                }

            }
            
            for (int j = 0; j < ListaAlumnos.size(); j++) { // Este for tiene que ir fuera del while para que no se duplique el voto 
                
                
                for (Alumno aux : alumnosVotados) {

                    if (ListaAlumnos.get(j).equals(aux)) {

                        ListaAlumnos.get(j).setVotos(ListaAlumnos.get(j).getVotos() + 1);
                        continue;
                    }
                }

            }
            
            System.out.println("***********************************");
            
            v.setAlumnosVotados(alumnosVotados);
            votos.add(v);
            
        }
        
        return votos;
        
        
    }
    
    /*Se debe crear un método que muestre a cada Alumno con su cantidad de votos y cuales
fueron sus 3 votos.*/
    
    public void MostrarVotos (ArrayList<Alumno> ListaAlumnos, ArrayList<Voto> votos){
        
        for (int i = 0; i < ListaAlumnos.size(); i++) {
            
            Alumno alumnoActual = ListaAlumnos.get(i);
            System.out.println(alumnoActual.getNombre()+" tuvo "+alumnoActual.getVotos()+" votos. y voto a");
            
            for (int j = 0; j < votos.size(); j++) {
                
                if(votos.get(j).getAlum().equals(alumnoActual)){
                    
                    System.out.println(votos.get(j).getAlumnosVotados());
                    break;
                }
                
            }
            
            
        }
        
        
    }
    
    
/*    Se debe crear un método que haga el recuento de votos, este recibe la lista de Alumnos y
comienza a hacer el recuento de votos.*/
    
    public void recuentoVotos (ArrayList<Alumno> ListaAlumnos){
        
        System.out.println("*********************************");
        System.out.println("*****RECUENTO DE VOTOS***********");
        for (Alumno aux : ListaAlumnos) {
            
            System.out.println("El alumno "+aux.getNombre()+" tuvo "+aux.getVotos()+" votos.");
            
            
        }
    }
    
    
    /*Se deben crear 5 facilitadores con los 5 primeros alumnos votados y se deben crear 5
facilitadores suplentes con los 5 segundos alumnos más votados. A continuación, mostrar
los 5 facilitadores y los 5 facilitadores suplentes*/
    
    public void facilitadores (ArrayList<Alumno> ListaAlumnos){
        
        Collections.sort(ListaAlumnos, new comparadores());
        
        System.out.println("Los Facilitadores son:");
        
        for (int i=0; i<5; i++) {
            
            System.out.println(ListaAlumnos.get(i).getNombre());
        }
        
        System.out.println("**************************");
     
        System.out.println("Los Suplentes son:");
        
        for (int i=5; i<10; i++) {
            
            System.out.println(ListaAlumnos.get(i).getNombre());
        }
        
        
        
    }
    
}
